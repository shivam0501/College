from django import forms
from .models import FDR, CostTable, Tower, OPERATING_COMPANY,TriageActionTracker,\
    SolutionSketchActionTracker, StatementOfWorkActionTracker
from accounts.models import Account


class NewFDRForm(forms.ModelForm):
    class Meta:
        x=Account.objects.all().filter(user_designation ='PM')
        pm_name=tuple([(i.first_name, i.first_name) for i in x])
        model=FDR
        project_manager=forms.ChoiceField(choices=pm_name)
        widgets = {
            'project_description': forms.Textarea(attrs={'rows':4, 'cols':15}),
        }
        fields=[
            'fdr_no',
            'fdr_type','opco','project_no',
            'department','project_title','project_description',
            'project_manager',
            'proposal_lead','pl_comment','pl_status',
            'tower_1','comment_t1','status_t1',
            'tower_2','comment_t2','status_t2',
            'tower_3','comment_t3','status_t3',
            'tower_4','comment_t4','status_t4',
            'tower_5','comment_t5','status_t5',
            'tower_6','comment_t6','status_t6',
            'image','business_user'
        ]

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        if user is not None:
            fields_list = [
                'fdr_no',
                'fdr_type','opco','project_no',
                'department','project_title','project_description',
                'image'
            ]

            if user.user_designation == 'PL':
                fields_list += [
                    'proposal_lead', 'pl_comment', 'pl_status',
                ]
            elif user.user_designation == 'PM':
                fields_list += [
                    'project_manager',
                ]
            elif user.user_designation == 'II' and user.is_user_SME:
                if user.user_tower == 'EUC':
                    fields_list += [
                        'tower_1','comment_t1','status_t1',
                    ]
                if user.user_tower == 'NET':
                    fields_list += [
                        'tower_2','comment_t2','status_t2',
                    ]
                if user.user_tower == 'SOP':
                    fields_list += [
                        'tower_3','comment_t3','status_t3',
                    ]
                if user.user_tower == 'SDC':
                    fields_list += [
                        'tower_4','comment_t4','status_t4',
                    ]
                if user.user_tower == 'ADM':
                    fields_list += [
                        'tower_5','comment_t5','status_t5',
                    ]
                if user.user_tower == 'MIS':
                    fields_list += [
                        'tower_6','comment_t6','status_t6',
                    ]


            fields_list = set(fields_list)
            for field_name in self.fields.copy():
                if field_name not in fields_list:
                    self.fields.pop(field_name, None)

class CostTableForm(forms.ModelForm):
    form_types = (
            ('','Select Type'),
            ('IC', 'Internal Capex'),
            ('IO', 'Internal Opex'),
            ('EC', 'External Capex'),
            ('EO', 'External Opex'),
        )
    form_type = forms.ChoiceField(choices=form_types)


    class Meta:
        model = CostTable
        tower = forms.ChoiceField(choices=Tower)
        is_capex = forms.BooleanField()
        is_internal = forms.BooleanField()
        is_external = forms.BooleanField()
        is_opex = forms.BooleanField()
        opco = forms.ChoiceField(choices=OPERATING_COMPANY)
        widgets = {
            'cost_description': forms.Textarea(attrs={'rows': 1, 'cols': 25}),

        }
        fields = [
            'tower',
            'cost_description',
            'form_type',
            'cost_type',
            'opco',
            'is_capex',
            'is_internal',
            'is_opex',
            'is_external',
            'rate_1',
            'unit_1',
            'rate_2',
            'unit_2',
            'rate_3',
            'unit_3',
            'rate_4',
            'unit_4',
            'rate_5',
            'unit_5',
        ]
    def __init__(self, *args, **kwargs):
        initial = kwargs.get('initial', {})
        initial['is_capex']=False
        initial['is_opex']=False
        initial['is_internal']=False
        initial['is_external']=False
        kwargs['initial']=initial
        super(CostTableForm, self).__init__(*args, **kwargs)


class DateInput(forms.DateInput):
    input_type = 'date'


class TriageActionTrackerForm(forms.ModelForm):
    # x=list(FDR.objects.all().using('central_db'))
    # print(x)
    fdr_no=forms.ModelChoiceField(queryset=FDR.objects.all().using('central_db'))
    received_date = forms.DateTimeField(input_formats=['%d/%m/%Y'])
    class Meta:
        model= TriageActionTracker
        widgets = {
            'action_tracker': forms.Textarea(attrs={'rows': 1, 'cols': 25}),
        }
        fields=[
            'fdr_no',
            'action_owner',
            'action_tracker',
            'received_date',
        ]

class SolutionSketchActionTrackerForm(forms.ModelForm):
    cost_status_choices=(
        ('','Select Status'),
        ('Provided','Cost Provided'),
        ('Pending','Cost Pending'),
    )
    cab_status_choices=(
        ('','Select Status'),
        ('Pending','Pending'),
        ('Approved','Approved'),
        ('Reject','Reject'),
    )
    fdr_no=forms.ModelChoiceField(queryset=FDR.objects.all().using('central_db'))
    received_date = forms.DateTimeField(input_formats=['%d/%m/%Y'])
    meeting_1_date = forms.DateTimeField(input_formats=['%d/%m/%Y'])
    meeting_2_date = forms.DateTimeField(input_formats=['%d/%m/%Y'])
    meeting_3_date = forms.DateTimeField(input_formats=['%d/%m/%Y'])
    cost_status = forms.ChoiceField(choices=cost_status_choices)
    CAB_status = forms.ChoiceField(choices=cab_status_choices)
    class Meta:
        model = SolutionSketchActionTracker
        widgets = {
            'meeting_1_notes': forms.Textarea(attrs={'rows': 1, 'cols': 25}),
            'meeting_2_notes': forms.Textarea(attrs={'rows': 1, 'cols': 25}),
            'meeting_3_notes': forms.Textarea(attrs={'rows': 1, 'cols': 25}),
            'CAB_comment': forms.Textarea(attrs={'rows': 1, 'cols': 25}),
            'SS_comment': forms.Textarea(attrs={'rows': 1, 'cols': 25}),
        }
        fields=[
            'fdr_no',
            'received_date',
            'meeting_1_notes',
            'meeting_2_notes',
            'meeting_3_notes',
            'meeting_1_date',
            'meeting_2_date',
            'meeting_3_date',
            'ROM_cost',
            'cost_status',
            'CAB_status',
            'CAB_comment',
            'SS_status',
            'SS_comment',
        ]

    def __init__(self, *args, **kwargs):
        super(SolutionSketchActionTrackerForm, self).__init__(*args, **kwargs)
        self.fields['meeting_2_date'].required = False
        self.fields['meeting_3_date'].required = False
        self.fields['meeting_2_notes'].required = False
        self.fields['meeting_3_notes'].required = False


class StatementOfWorkActionTrackerForm(forms.ModelForm):
    cost_status_choices=(
        ('','Select Status'),
        ('Provided','Cost Provided'),
        ('Pending','Cost Pending'),
    )
    cab_status_choices=(
        ('','Select Status'),
        ('Pending','Pending'),
        ('Approved','Approved'),
        ('Reject','Reject'),
    )
    fdr_no=forms.ModelChoiceField(queryset=FDR.objects.all().using('central_db'))
    received_date = forms.DateTimeField(input_formats=['%d/%m/%Y'])
    meeting_1_date = forms.DateTimeField(input_formats=['%d/%m/%Y'])
    meeting_2_date = forms.DateTimeField(input_formats=['%d/%m/%Y'])
    meeting_3_date = forms.DateTimeField(input_formats=['%d/%m/%Y'])
    cost_status = forms.ChoiceField(choices=cost_status_choices)
    CAB_status = forms.ChoiceField(choices=cab_status_choices)
    class Meta:
        model = StatementOfWorkActionTracker
        widgets = {
            'meeting_1_notes': forms.Textarea(attrs={'rows': 1, 'cols': 25}),
            'meeting_2_notes': forms.Textarea(attrs={'rows': 1, 'cols': 25}),
            'meeting_3_notes': forms.Textarea(attrs={'rows': 1, 'cols': 25}),
            'CAB_comment': forms.Textarea(attrs={'rows': 1, 'cols': 25}),
            'SOW_comment': forms.Textarea(attrs={'rows': 1, 'cols': 25}),
        }
        fields=[
            'fdr_no',
            'received_date',
            'meeting_1_notes',
            'meeting_2_notes',
            'meeting_3_notes',
            'meeting_1_date',
            'meeting_2_date',
            'meeting_3_date',
            'committed_cost',
            'cost_status',
            'CAB_status',
            'CAB_comment',
            'SOW_status',
            'SOW_comment',
        ]

    def __init__(self, *args, **kwargs):
        super(StatementOfWorkActionTrackerForm, self).__init__(*args, **kwargs)
        self.fields['meeting_2_date'].required = False
        self.fields['meeting_3_date'].required = False
        self.fields['meeting_2_notes'].required = False
        self.fields['meeting_3_notes'].required = False