from django.shortcuts import render, redirect
from .forms import NewFDRForm, CostTableForm, TriageActionTrackerForm, \
	SolutionSketchActionTrackerForm, StatementOfWorkActionTrackerForm
import datetime
from .models import FDR, Cost_sheet, CostTable, Financial_year_rate, TriageActionTracker, \
	SolutionSketchActionTracker, StatementOfWorkActionTracker
from django.contrib.auth.decorators import login_required
from django.db.models import Sum, ExpressionWrapper, F, FloatField
from django.db.models import Q
from pprint import pprint
import itertools
from django.core.paginator import Paginator


# Create your views here.
@login_required(login_url='home')
def dashboard_home(request):
	# current_user = request.user
	print(request.session['user_opco'])
	context = {}
	# print(current_user.user_operating_company)
	opco_filter = None
	if request.session['user_opco'] == 'UK_air_db':
		opco_filter = 'UKA'
	elif request.session['user_opco'] == 'Spanish_air_db':
		opco_filter = 'SPA'
	elif request.session['user_opco'] == 'Portugal_air_db':
		opco_filter = 'POA'
	elif request.session['user_opco'] == 'Irish_air_db':
		opco_filter = 'IRA'
	elif request.session['user_opco'] == 'Belgian_air_db':
		opco_filter = 'BLA'

	# print('\n', request.session['user_designation'], '\n', request.session['name'], '\n')
	if not opco_filter:
		context['FDR'] = FDR.objects.filter(~Q(proposal_lead = '')).using('central_db')
		# paginator1 = Paginator(context['FDR'], 10)
		# page_number = request.GET.get('page')
		# page_obj = paginator1.get_page(page_number)
		# context['page_obj_FDR'] = page_obj

		context['my_FDR'] = FDR.objects.filter(proposal_lead = request.session['name']).using('central_db')
		context['new_FDR'] = FDR.objects.filter(proposal_lead = '').using('central_db')
	else:
		if request.session['user_designation'] == 'BU':
			context['FDR'] = FDR.objects.filter(opco=opco_filter).using('central_db')
			context['my_FDR'] = FDR.objects.filter(opco=opco_filter, business_user=request.session['name']).using('central_db')
		if request.session['user_designation'] == 'PM':
			context['FDR'] = FDR.objects.filter(~Q(project_manager=''), opco=opco_filter).using('central_db')
			context['my_FDR'] = FDR.objects.filter(opco=opco_filter, project_manager=request.session['name']).using('central_db')
			context['new_FDR'] = FDR.objects.filter(opco=opco_filter, project_manager='').using('central_db')
		if request.session['user_designation'] == 'II':
			print(request.session['user_designation'])
			if request.session['user_tower'] == 'EUC':
				print(request.session['user_tower'])
				context['FDR'] = FDR.objects.filter(~Q(tower_1 = ''), opco=opco_filter).using('central_db')
				context['my_FDR'] = FDR.objects.filter(opco=opco_filter, tower_1=request.session['name']).using('central_db')
				context['new_FDR'] = FDR.objects.filter(tower_1='', opco=opco_filter).using('central_db')
			elif request.session['user_tower'] == 'NET':
				context['FDR'] = FDR.objects.filter(~Q(tower_2= ''), opco=opco_filter).using('central_db')
				context['my_FDR'] = FDR.objects.filter(opco=opco_filter, tower_2=request.session['name']).using('central_db')
				context['new_FDR'] = FDR.objects.filter(tower_2 ='', opco=opco_filter).using('central_db')
			elif request.session['user_tower'] == 'SOP':
				context['FDR'] = FDR.objects.filter(~Q(tower_3 = ''), opco=opco_filter).using('central_db')
				context['my_FDR'] = FDR.objects.filter(opco=opco_filter, tower_3=request.session['name']).using('central_db')
				context['new_FDR'] = FDR.objects.filter(tower_3 ='', opco=opco_filter).using('central_db')
			elif request.session['user_tower'] == 'SDC':
				context['FDR'] = FDR.objects.filter(~Q(tower_4 = ''), opco=opco_filter).using('central_db')
				context['my_FDR'] = FDR.objects.filter(opco=opco_filter, tower_4=request.session['name']).using('central_db')
				context['new_FDR'] = FDR.objects.filter(tower_4 = '', opco=opco_filter).using('central_db')
			elif request.session['user_tower'] == 'ADM':
				context['FDR'] = FDR.objects.filter(~Q(tower_5 = ''), opco=opco_filter).using('central_db')
				context['my_FDR'] = FDR.objects.filter(opco=opco_filter, tower_5=request.session['name']).using('central_db')
				context['new_FDR'] = FDR.objects.filter(tower_5 = '', opco=opco_filter).using('central_db')
			elif request.session['user_tower'] == 'MIS':
				context['FDR'] = FDR.objects.filter(~Q(tower_6 = ''), opco=opco_filter).using('central_db')
				context['my_FDR'] = FDR.objects.filter(opco=opco_filter, tower_6=request.session['name']).using('central_db')
				context['new_FDR'] = FDR.objects.filter(tower_6 = '', opco=opco_filter).using('central_db')

			# context['my_FDR'] = FDR.objects.filter(opco=opco_filter, project_manager=request.session['name']).using('central_db')
			# context['new_FDR'] = FDR.objects.filter(opco=opco_filter, project_manager='').using('central_db')

	return render(request, 'dash_home.html', context)


@login_required(login_url='home')
def create_fdr(request):
	if request.method == 'POST':
		form = NewFDRForm(request.POST, request.FILES)
		# object of cost sheet
		obj = Cost_sheet()
		print(form.errors)
		if form.is_valid():
			f = form.save(commit=False)
			f.business_user = request.session['name']
			f.save(using='central_db')
			obj.fdr_no = f
			x = datetime.datetime.now().year
			obj.year_1 = x
			obj.year_2 = x + 1
			obj.year_3 = x + 2
			obj.year_4 = x + 3
			obj.year_5 = x + 4
			obj.year_6 = x + 5
			obj.save(using='central_db')
			return redirect('dashboard')
		return render(request, 'create_fdr.html', {'form': form})
	else:
		form = NewFDRForm()
		return render(request, 'create_fdr.html', {'form': form})


@login_required(login_url='home')
def update_fdr(request, pk):
	fdr = FDR.objects.using('central_db').get(fdr_no=pk)
	# print(fdr.proposal_lead)
	if request.method == 'POST':
		# print(request.POST)
		form = NewFDRForm(request.POST, request.FILES, instance=fdr, user=request.user)
		# print(form.errors)
		if form.is_valid():
			# print(form.cleaned_data)
			f = form.save(commit=False)
			f.save(using='central_db')
			return redirect('dashboard')
	form = NewFDRForm(instance=fdr, user=request.user)
	context = {'form': form, 'fdr_no': pk}
	# print(context['fdr_no'])
	return render(request, 'view_fdr.html', context)


def calculate_grand(external_data):
	grand_external = {}
	for key, group in itertools.groupby(external_data, lambda x: x['tower']):
		# print(key, list(group))
		val_list = {f'year_{i + 1}': 0 for i in range(5)}
		iter_list = [('rate_1', 'unit_1'), ('rate_2', 'unit_2'), ('rate_3', 'unit_3'), ('rate_4', 'unit_4'),
					 ('rate_5', 'unit_5')]
		for g in group:
			for idx, tup in enumerate(iter_list):
				val_list[f'year_{idx + 1}'] += g[tup[0]] * g[tup[1]]
		val_list['total'] = sum(val_list.values())
		grand_external[key] = val_list
	grand_total = sum([grand_external[key]['total'] for key in grand_external])
	return grand_external, grand_total


@login_required(login_url='home')
def costing_page(request, fk):
	cost_sheet = Cost_sheet.objects.using('central_db').get(fdr_no=fk)
	fdr = FDR.objects.using('central_db').get(fdr_no=fk)
	if request.method == 'POST':
		f = CostTableForm(request.POST)
		print(f.errors)
		if f.is_valid():
			form = f.save(commit=False)
			f_type = f.cleaned_data['form_type']
			print(f_type)
			if f_type == 'IO':
				form.is_internal = True
				form.is_opex = True
			elif f_type == 'IC':
				form.is_internal = True
				form.is_capex = True
			elif f_type == 'EC':
				form.is_external = True
				form.is_capex = True
			else:
				form.is_external = True
				form.is_opex = True
			form.sheet_no = cost_sheet
			form.save(using='central_db')
			cost_sheet.save(using='central_db')
			return redirect('view_costing_sheet', fk)
	cost_table_form = CostTableForm()

	entries = CostTable.objects.filter(sheet_no=cost_sheet).using('central_db')
	grand_external, grand_external_total = calculate_grand(
		list(entries.filter(is_external=True).order_by('tower').values()))
	grand_internal, grand_internal_total = calculate_grand(
		list(entries.filter(is_internal=True).order_by('tower').values()))
	internal_capex_data = entries.filter(is_internal=True, is_capex=True)
	internal_opex_data = entries.filter(is_internal=True, is_opex=True)
	external_capex_data = entries.filter(is_external=True, is_capex=True)
	external_opex_data = entries.filter(is_external=True, is_opex=True)

	context = {
		'cost_sheet': cost_sheet,
		'fdr': fdr,
		'cost_table_form': cost_table_form,
		'internal_capex_data': internal_capex_data,
		'internal_opex_data': internal_opex_data,
		'external_capex_data': external_capex_data,
		'external_opex_data': external_opex_data,
		'external_grand_data': grand_external,
		'internal_grand_data': grand_internal,
		'external_grand_total': grand_external_total,
		'internal_grand_total': grand_internal_total,
	}
	return render(request, 'cost_sheet/cost_sheet.html', context)


@login_required(login_url='home')
def view_triage_action_tracker(request):
	if request.method == 'POST':
		f = TriageActionTrackerForm(request.POST)
		print(f.errors)
		if f.is_valid:
			form = f.save(commit=False)
			form.save(using='central_db')
		return redirect('triage-action-tracker')
	else:
		triage_action_trackers = TriageActionTracker.objects.using('central_db')
		form = TriageActionTrackerForm()
		context = {
			'trackers': triage_action_trackers,
			'form': form,
		}
		return render(request, 'action_trackers/triage.html', context)


@login_required(login_url='home')
def view_solution_sketch_action_tracker(request):
	if request.method == 'POST':
		f = SolutionSketchActionTrackerForm(request.POST)
		print(f.errors)
		if f.is_valid:
			form = f.save(commit=False)
			form.save(using='central_db')
		return redirect('solution-sketch-action-tracker')
	else:
		solution_sketch_trackers = SolutionSketchActionTracker.objects.using('central_db')
		form = SolutionSketchActionTrackerForm()
		context = {
			'form': form,
			'trackers': solution_sketch_trackers,
		}
		return render(request, 'action_trackers/solution_sketch.html', context)


@login_required(login_url='home')
def view_statement_of_work_action_tracker(request):
	if request.method == 'POST':
		f = StatementOfWorkActionTrackerForm(request.POST)
		print(f.errors)
		if f.is_valid:
			form = f.save(commit=False)
			form.save(using='central_db')
		return redirect('statement-of-work-action-tracker')
	else:
		statement_of_work_trackers = StatementOfWorkActionTracker.objects.using('central_db')
		form = StatementOfWorkActionTrackerForm()
		context = {
			'form': form,
			'trackers': statement_of_work_trackers,
		}
		return render(request, 'action_trackers/statement_of_work.html', context)


def dummy(request):
	srh = request.POST['query']
	opco_filter = None
	if request.session['user_opco'] == 'UK_air_db':
		opco_filter = 'UKA'
	elif request.session['user_opco'] == 'Spanish_air_db':
		opco_filter = 'SPA'
	elif request.session['user_opco'] == 'Portugal_air_db':
		opco_filter = 'POA'
	elif request.session['user_opco'] == 'Irish_air_db':
		opco_filter = 'IRA'
	elif request.session['user_opco'] == 'Belgian_air_db':
		opco_filter = 'BLA'
	fdr = FDR.objects.filter(project_description__icontains=srh, opco=opco_filter).using('central_db')
	for i in fdr:
		print(i)
	params = {'search_results': fdr}
	return render(request, 'test.html', params)


def SearchPage(request):
	srh = request.GET['query']
	fdr = FDR.objects.filter(name__icontains=srh)
	params = {'search_results': fdr, 'search': srh}
	return render(request, 'test.html', params)
