from django.urls import path
from . import views
from accounts.views import logout_view
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf import settings

urlpatterns=[
    path('', views.dashboard_home, name='dashboard'),
    path('createfdr',views.create_fdr,name='fdr'),
    path('updatefdr/<str:pk>/',views.update_fdr,name='view_fdr'),
    path('costing/<str:fk>/',views.costing_page,name='view_costing_sheet'),
    path('action-tracker/', views.view_triage_action_tracker, name='triage-action-tracker'),
    path('solution-sketch-tracker/', views.view_solution_sketch_action_tracker, name='solution-sketch-action-tracker'),
    path('statement-of-work-tracker/', views.view_statement_of_work_action_tracker, name='statement-of-work-action-tracker'),
    path('dummy/', views.dummy, name='dummy'),
]

if settings.DEBUG:
    #urlpatterns += staticfiles_urlpatterns()
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)