from django import template

register = template.Library()

def multiply(value, *args):
    ans = 1
    for i in args:
        ans *= i
    return value * ans

@register.simple_tag(name='addition')
def addition(value, *args):
    return value + sum(args)

@register.simple_tag(name='special_add')
def special_addition(rate_1, unit_1, rate_2, unit_2, rate_3, unit_3, rate_4, unit_4, rate_5, unit_5):
    return ((rate_1*unit_1)+(rate_2*unit_2)+(rate_3*unit_3)+(rate_4*unit_4)+(rate_5*unit_5))

@register.simple_tag(takes_context=True, name='set')
def set(context, key, value):
    context.dicts[0][key] = value
    return ''

# @register.simple_tag(name='slice')
# def slice(string, str2):
#     return list(str(string).split(':'))[0]
