from django.db.models.deletion import CASCADE
from djongo import models
from django.db import transaction
import datetime
from accounts.models import Account
from django.contrib import admin

# Choice Variables
OPERATING_COMPANY = (
    ('', 'Select Operating Company'),
    ('UKA', 'UK Air'),
    ('IRA', 'Irish Air'),
    ('SPA', 'Spanish Air'),
    ('BLA', 'Belgian Air'),
    ('POA', 'Air Portugal'),
)
Tower = (
    ('', 'Select Tower'),
    ('EUC', 'End User Computing'),  # tower 1
    ('NET', 'Networks'),  # tower 2
    ('SOP', 'Security Operations'),  # tower 3
    ('SDC', 'Servers & Data Centers'),  # tower 4
    ('ADM', 'Application Development & Maintenance'),  # tower 5
    ('MIS', 'Miscellaneous Infrastructure'),  # tower 6
)

users = Account.objects.all().using('default')


class FDR(models.Model):
    fdr_no = models.AutoField(primary_key=True)

    FDR_STATUS = (
        ('', 'Select FDR Status'),
        ('O', 'Open'),
        ('C', 'Closed'),
    )
    fdr_status = models.CharField(max_length=1, choices=FDR_STATUS, default='O')

    date = models.DateField(auto_now_add=True)

    FDR_TYPE = (
        ('', 'Select FDR Type'),
        ('SS', 'Solution Sketch'),
        ('SOW', 'Statement Of Work'),
    )
    fdr_type = models.CharField(max_length=3, choices=FDR_TYPE)

    opco = models.CharField(max_length=3, choices=OPERATING_COMPANY)

    project_no = models.CharField(max_length=15)

    department = models.CharField(max_length=255)

    project_title = models.CharField(max_length=500)

    project_description = models.TextField()

    x = users.filter(user_designation='PM')
    pm_name = tuple([(i.first_name + ' ' + i.last_name, i.first_name + ' ' + i.last_name) for i in x])

    x = users.filter(user_designation='PL')
    pl_name = tuple([(i.first_name + ' ' + i.last_name, i.first_name + ' ' + i.last_name) for i in x])

    x = users.filter(user_designation='II')
    ii_name = tuple([(i.first_name + ' ' + i.last_name, i.first_name + ' ' + i.last_name) for i in x])

    business_user = models.CharField(max_length=255, blank=True)

    project_manager = models.CharField(max_length=50, choices=pm_name, blank=True)
    PL_STATUS = (
        ('', 'Select Status'),
        ('NA', 'Not Assigned'),
        ('A', 'Assigned'),
        ('ROT', 'Ready For Triage'),
        ('APP', 'Approved'),
        ('P', 'Pending'),
        ('IP', 'In Progress'),
        ('C', 'Completed')
    )
    T_STATUS = (
        ('', 'Select Status'),
        ('Not Assigned', 'Not Assigned'),
        ('Assigned', 'Assigned'),
        ('Cost Pending', 'Cost Pending'),
        ('Cost Provided', 'Cost Provided'),
    )
    proposal_lead = models.CharField(max_length=50, choices=pl_name, blank=True)
    pl_comment = models.CharField(max_length=500, blank=True)
    pl_status = models.CharField(max_length=3, choices=PL_STATUS, blank=True)

    tower_1 = models.CharField(max_length=50, choices=ii_name, blank=True)
    comment_t1 = models.CharField(max_length=500, blank=True)
    status_t1 = models.CharField(max_length=20, choices=T_STATUS, blank=True)

    tower_2 = models.CharField(max_length=50, choices=ii_name, blank=True)
    comment_t2 = models.CharField(max_length=500, blank=True)
    status_t2 = models.CharField(max_length=20, choices=T_STATUS, blank=True)

    tower_3 = models.CharField(max_length=50, choices=ii_name, blank=True)
    comment_t3 = models.CharField(max_length=500, blank=True)
    status_t3 = models.CharField(max_length=20, choices=T_STATUS, blank=True)

    tower_4 = models.CharField(max_length=50, choices=ii_name, blank=True)
    comment_t4 = models.CharField(max_length=500, blank=True)
    status_t4 = models.CharField(max_length=20, choices=T_STATUS, blank=True)

    tower_5 = models.CharField(max_length=50, choices=ii_name, blank=True)
    comment_t5 = models.CharField(max_length=500, blank=True)
    status_t5 = models.CharField(max_length=20, choices=T_STATUS, blank=True)

    tower_6 = models.CharField(max_length=50, choices=ii_name, blank=True)
    comment_t6 = models.CharField(max_length=500, blank=True)
    status_t6 = models.CharField(max_length=20, choices=T_STATUS, blank=True)

    image = models.FileField(null=True, blank=True, upload_to='files/')

    def __str__(self):
        return str(self.fdr_no) + ': ' + self.project_title + '-' + self.opco

    def save(self, *args, **kwargs):
        if self.pl_status == 'C':
            self.fdr_status = 'C'
        super(FDR, self).save(*args, **kwargs)


# Costing sheet model below
class Cost_sheet(models.Model):
    sheet_no = models.AutoField(primary_key=True)
    Last_update = models.DateTimeField()
    fdr_no = models.ForeignKey(FDR, on_delete=models.CASCADE, related_name='fdr_cost_link', default=None)

    year_1 = models.IntegerField()
    year_2 = models.IntegerField()
    year_3 = models.IntegerField()
    year_4 = models.IntegerField()
    year_5 = models.IntegerField()
    year_6 = models.IntegerField()

    def save(self, *args, **kwargs):
        self.Last_update = datetime.datetime.now()
        super(Cost_sheet, self).save(*args, **kwargs)

    def __str__(self):
        return f'Cost Sheet No. {self.sheet_no} | FDR No. {self.fdr_no}'


class CostTable(models.Model):
    sheet_no = models.ForeignKey(Cost_sheet, on_delete=models.CASCADE, related_name='costtable_costsheet_link')
    sr_no = models.AutoField(primary_key=True)
    tower = models.CharField(max_length=50, choices=Tower, blank=True)
    cost_description = models.TextField(max_length=500)
    cost_type = models.CharField(max_length=50)
    is_capex = models.BooleanField(default=False)
    is_opex = models.BooleanField(default=False)
    is_internal = models.BooleanField(default=False)
    is_external = models.BooleanField(default=False)
    opco = models.CharField(max_length=3, choices=OPERATING_COMPANY)

    rate_1 = models.FloatField()
    unit_1 = models.IntegerField()

    rate_2 = models.FloatField()
    unit_2 = models.IntegerField()

    rate_3 = models.FloatField()
    unit_3 = models.IntegerField()

    rate_4 = models.FloatField()
    unit_4 = models.IntegerField()

    rate_5 = models.FloatField()
    unit_5 = models.IntegerField()

    def __str__(self):
        return f'Cost Table {self.sr_no} | {self.sheet_no}'

    def net(self):
        return self.rate_1 * self.unit_1 + self.rate_2 * self.unit_2 + self.rate_3 * self.unit_3 + self.rate_4 * self.unit_4 + self.rate_5 * self.unit_5


# Table for financial year
class Financial_year_rate(models.Model):
    sr_no = models.ForeignKey(CostTable, on_delete=models.CASCADE, related_name='costing_year_link')
    _id = models.ObjectIdField(primary_key=True)
    year = models.DateField()
    rate = models.FloatField()
    unit = models.IntegerField()

    def __str__(self):
        return f'Rate Table for Year {self.year} | {self.sr_no}'

    # class Meta:
    #     unique_together=['sr_no','year']


class TriageActionTracker(models.Model):
    fdr_no = models.ForeignKey(FDR, on_delete=models.CASCADE, related_name='triage_action_tracker_link')
    # sr_no = models.AutoField(primary_key=True)
    _id = models.ObjectIdField(primary_key=True)
    action_tracker = models.TextField()
    owners = tuple([(i.first_name, i.first_name) for i in users])
    action_owner = models.CharField(max_length=255, choices=owners)
    received_date = models.DateField()

    def __str__(self):
        return str(self.fdr_no) + ' ' + str(self.action_owner)

    def get_fdr_no(self):
        return str(self.fdr_no.fdr_no)


class SolutionSketchActionTracker(models.Model):
    fdr_no = models.ForeignKey(FDR, on_delete=models.CASCADE, related_name='solution_sketch_action_tracker_link')
    _id = models.ObjectIdField(primary_key=True)
    received_date = models.DateField(blank=True)
    meeting_1_date = models.DateField(blank=True)
    meeting_1_notes = models.TextField(max_length=500, blank=True)
    meeting_2_date = models.DateField(blank=True)
    meeting_2_notes = models.TextField(max_length=500, blank=True)
    meeting_3_date = models.DateField(blank=True)
    meeting_3_notes = models.TextField(max_length=500, blank=True)
    ROM_cost = models.IntegerField(blank=True)
    cost_status = models.CharField(max_length=20, blank=True)
    CAB_status = models.CharField(max_length=20, blank=True)
    CAB_comment = models.TextField(blank=True)
    SS_status = models.CharField(max_length=20, blank=True)
    SS_comment = models.TextField(blank=True)

    def __str__(self):
        return str(self.fdr_no) + ' ' + str(self.fdr_no.project_no)

    def get_fdr_no(self):
        return str(self.fdr_no.fdr_no)


class StatementOfWorkActionTracker(models.Model):
    fdr_no = models.ForeignKey(FDR, on_delete=models.CASCADE, related_name='statement_of_work_action_tracker_link')
    _id = models.ObjectIdField(primary_key=True)
    received_date = models.DateField(blank=True)
    meeting_1_date = models.DateField(blank=True)
    meeting_1_notes = models.TextField(max_length=500, blank=True)
    meeting_2_date = models.DateField(blank=True)
    meeting_2_notes = models.TextField(max_length=500, blank=True)
    meeting_3_date = models.DateField(blank=True)
    meeting_3_notes = models.TextField(max_length=500, blank=True)
    committed_cost = models.IntegerField(blank=True)
    cost_status = models.CharField(max_length=20, blank=True)
    CAB_status = models.CharField(max_length=20, blank=True)
    CAB_comment = models.TextField(blank=True)
    SOW_status = models.CharField(max_length=20, blank=True)
    SOW_comment = models.TextField(blank=True)

    def __str__(self):
        return str(self.fdr_no) + ' ' + str(self.fdr_no.project_no)

    def get_fdr_no(self):
        return str(self.fdr_no.fdr_no)
