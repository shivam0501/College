from django import forms
from django.contrib.auth.forms import AuthenticationForm
from django.db.models.enums import Choices
from .models import Account


class New_Login_Form(AuthenticationForm):
    user_operating_company = forms.ChoiceField(choices=Account.Operating_companies)
    user_designation = forms.ChoiceField(choices=Account.Designations)


