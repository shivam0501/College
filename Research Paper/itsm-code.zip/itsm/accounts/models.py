from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager


class MyAccountManager(BaseUserManager):
	def create_user(
		self,
		email,
		first_name,
		last_name,
		user_operating_company,
		user_designation,
		user_tower,
		is_user_UKAIR,
		is_user_BELAIR,
		is_user_POAIR,
		is_user_SPANAIR,
		is_user_IRAIR,
		is_user_TT,
		is_user_SME,
		password=None
		):
		if not email:
			raise ValueError('Users must have an email address')
		if not first_name:
			raise ValueError('Users must have a First Name')
		if not last_name:
			raise ValueError('Users must have a Last Name')
		if not user_operating_company:
			raise ValueError('Users must have a Operating Company')
		if not user_designation:
			raise ValueError('Users must have a Designations')

		user = self.model(
			email = self.normalize_email(email),
			first_name = first_name.lower(),
			last_name = last_name.lower(),
			user_operating_company = user_operating_company,
			user_designation = user_designation,
			user_tower = user_tower,
			is_user_UKAIR = is_user_UKAIR,
			is_user_BELAIR = is_user_BELAIR,
			is_user_POAIR = is_user_POAIR,
			is_user_SPANAIR = is_user_SPANAIR,
			is_user_IRAIR = is_user_IRAIR,
			is_user_TT = is_user_TT,
			is_user_SME = is_user_SME,
			)

		user.set_password(password)
		user.save(using=self._db)
		return user

	def create_superuser(
		self,
		email,
		password,
		first_name,
		last_name,
		user_operating_company,
		user_designation,
		user_tower,
		is_user_UKAIR,
		is_user_BELAIR,
		is_user_POAIR,
		is_user_SPANAIR,
		is_user_IRAIR,
		is_user_TT,
		is_user_SME,
		):
		user = self.create_user(
			email=self.normalize_email(email),
			password=password,
			first_name=first_name.lower(),
			last_name=last_name.lower(),
			user_operating_company=user_operating_company,
			user_designation=user_designation,
			user_tower = user_tower,
			is_user_UKAIR = True,
			is_user_BELAIR = True,
			is_user_POAIR = True,
			is_user_SPANAIR = True,
			is_user_IRAIR = True,
			is_user_TT = True,
			is_user_SME = True,
		)
		user.is_superuser = True
		user.is_admin = True
		user.is_staff = True
		user.save(using=self._db)
		return user


class Account(AbstractBaseUser):

	Operating_companies=[
		('','Select Operating Companies'),
		('Belgian_air_db','Belgian Airways'),
		('UK_air_db','UK Airways'),
		('Portugal_air_db','Air Portugal'),
		('Irish_air_db','Irish Air'),
		('Spanish_air_db','Spanish Air'),
		('Tag_tech_db','TAG Tech'),
	]

	operating_companies_bool = {
		'Belgian_air_db': 'is_user_BELAIR',
		'UK_air_db': 'is_user_UKAIR',
		'Portugal_air_db': 'is_user_POAIR',
		'Irish_air_db': 'is_user_IRAIR',
		'Spanish_air_db': 'is_user_SPANAIR',
		'Tag_tech_db': 'is_user_TT',
	}

	Designations=[
		('','Select User'),
		('BU','Business User'),
		('PL','Proposal Lead'),
		('PM','Project Manager'),
		('II','IT/Infra'),
	]

	Tower = (
		('', 'Select Tower'),
		('EUC', 'End User Computing'),
		('NET', 'Networks'),
		('SOP', 'Security Operations'),
		('SDC', 'Servers & Data Centers'),
		('ADM', 'Application Development & Maintenance'),
		('MIS', 'Miscellaneous Infrastructure'),
	)

	email 					= models.EmailField(verbose_name="email", max_length=60, unique=True)
	first_name              = models.CharField(max_length= 255)
	last_name               = models.CharField(max_length=255)
	user_operating_company  = models.CharField(max_length=255, choices=Operating_companies)
	user_designation		= models.CharField(max_length=2, choices=Designations)
	user_tower				= models.CharField(max_length=3, choices=Tower, blank=True)
	date_joined				= models.DateTimeField(verbose_name='date joined', auto_now_add=True)
	last_login				= models.DateTimeField(verbose_name='last login', auto_now=True)
	is_admin				= models.BooleanField(default=False)
	is_active				= models.BooleanField(default=True)
	is_staff				= models.BooleanField(default=False)
	is_superuser			= models.BooleanField(default=False)
	is_user_UKAIR			= models.BooleanField(default=False)
	is_user_BELAIR			= models.BooleanField(default=False)
	is_user_POAIR			= models.BooleanField(default=False)
	is_user_SPANAIR			= models.BooleanField(default=False)
	is_user_IRAIR			= models.BooleanField(default=False)
	is_user_TT				= models.BooleanField(default=False)
	is_user_SME             = models.BooleanField(default=False)

	USERNAME_FIELD = 'email'
	REQUIRED_FIELDS = [
					'first_name',
					'last_name',
					'user_operating_company',
					'user_designation',
					'user_tower',
					'is_user_UKAIR',
					'is_user_BELAIR',
					'is_user_POAIR',
					'is_user_SPANAIR',
					'is_user_IRAIR',
					'is_user_TT',
					'is_user_SME'
		]

	objects = MyAccountManager()

	def __str__(self):
		return self.email

	# For checking permissions. to keep it simple all admin have ALL permissons
	def has_perm(self, perm, obj=None):
		return self.is_admin

	# Does this user have permission to view this app? (ALWAYS YES FOR SIMPLICITY)
	def has_module_perms(self, app_label):
		return True

	def user_matches_opco(self, opco):
		mask = self.operating_companies_bool.get(opco, False)
		if mask:
			return getattr(self, mask)
		return False