from django.urls import path, include
from django.contrib.auth import views as auth_views
from . import views

urlpatterns=[
    path('', views.HomeView.as_view(), name='home'),
    path('logout/',views.logout_view,name='logout'),
    path('login/', views.login_authentication, name='login'),
    path('switch-account/<str:opco>', views.switch_account, name='switch-account'),
    path(
        'reset-password/',
        auth_views.PasswordResetView.as_view(template_name='password_reset/password_reset.html'),
        name='reset_password'
    ),
    path(
        'reset-password-sent/',
        auth_views.PasswordResetDoneView.as_view(template_name='password_reset/password_reset_sent.html'),
        name='password_reset_done'
    ),
    path(
        'reset/<uidb64>/<token>',
        auth_views.PasswordResetConfirmView.as_view(template_name='password_reset/password_reset_form.html'),
        name='password_reset_confirm'
    ),
    path(
        'reset-password-complete/',
        auth_views.PasswordResetCompleteView.as_view(template_name='password_reset/password_reset_done.html'),
        name='password_reset_complete'
    ),
]