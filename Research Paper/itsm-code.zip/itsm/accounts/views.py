import django
from django.views.generic import View
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import New_Login_Form
from django.contrib import auth
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required


# Create your views here.

class HomeView(View):
	def post(self, request):
		pass

	def get(self, request):
		form = New_Login_Form()
		return render(request, 'index.html', {'form': form})


def login_authentication(request):
	if request.method == "POST":
		# print('---------->>>>>>> inside if')
		# print('---------->>>>>>>', request.POST)
		form = New_Login_Form(data=request.POST)
		print('---------->>>>>>>', form.errors)
		print('---------->>>>>>>', form.is_valid())
		if form.is_valid():
			print('---------->>>>>>> Inside form')
			email = request.POST['username']
			password = request.POST['password']
			user_opco = request.POST['user_operating_company']
			user_desig = request.POST['user_designation']
			user = authenticate(request, email=email, password=password)
			if user.user_matches_opco(user_opco) and user_desig == user.user_designation:
				if user:
					request.session['user_opco'] = user_opco
					request.session['user_designation'] = user_desig
					if user_desig == 'II':
						request.session['user_tower'] = user.user_tower
					request.session['name'] = user.first_name + ' ' + user.last_name
					print(f'\n{user_opco}\n')
					login(request, user)
					return redirect('dashboard')
			else:
				form = New_Login_Form()
				return render(request, 'index.html', {'form': form, 'err': 'Invalid Fields'})
		else:
			form = New_Login_Form()
			return render(request, 'index.html', {'form': form})
	else:
		form = New_Login_Form()
		return render(request, 'index.html', {'form': form})


@login_required(login_url='home')
def logout_view(request):
	logout(request)
	return redirect('home')


@login_required(login_url='home')
def switch_account(request, opco, backend='django.contrib.auth.backends.ModelBackend'):
	request.session['user_opco'] = opco
	# if(desig != 'NULL'):
	#     request.session['user_designation']=desig

	# Abuzar Changes
	if request.session['user_designation'] == 'PL':
		request.session['user_designation'] = 'PM'
	# user.user_designation='PM'
	# request.session.modified = True

	if opco == 'Tag_tech_db' and request.session['user_designation'] == 'PM':
		request.session['user_designation'] = 'PL'
	# user.user_designation='PL'
	# request.session.modified = True

	print('[INFO] SESSION DATA USER OPCO', request.session['user_opco'])
	print('[INFO] SESSION DATA USER DESIGNATION', request.session['user_designation'])

	# logout(request)
	# user = authenticate(request, email=email, password=password)
	# if user_opco == user.user_operating_company and user_desig == user.user_designation:
	#     if user:
	#         login(request, user)
	#         return redirect('dashboard')
	# else:
	#     form = New_Login_Form()
	#     return render(request, 'index.html', {'form': form, 'err': 'Invalid Fields'})
	# if request.user:
	#     login(request, request.user, backend='django.contrib.auth.backends.ModelBackend')
	#     return redirect('dashboard')
	# else:
	#     return render(request, 'test.html')

	return redirect('dashboard')
