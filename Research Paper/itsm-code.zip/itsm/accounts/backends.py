from django.contrib.auth.backends import BaseBackend
from django.http import request
from .models import Account
# from django_middleware_global_request.middleware import get_request

class CustomAuthenticate(BaseBackend):
    def authenticate(self, request, username=None, password=None, **kwargs):
        # self.db = db
        if username is None:
            username = kwargs.get(Account.USERNAME_FIELD)
        # print('---------->>>>>>> INSIDE AUTHENTICATION')
        try:
            user = Account.objects.get(email=username)
            # print('---------->>>>>>>', user, user.first_name)
            if user.check_password(password):
                # print('---------->>>>>>> PW Validated')
                return user
        except Account.DoesNotExist:
            return None

    def get_user(self, user_id):
        # print('---------->>>>>>> get_user')
        try:
            # print('---------->>>>>>> Inside try block\n---------->>>>>>>', user_id)
            user =  Account.objects.get(pk=user_id)
        except Account.DoesNotExist:
            return None
        return user if self.user_can_authenticate(user) else None

    def user_can_authenticate(self, user):
        is_active = getattr(user, 'is_active', None)
        return is_active or is_active is None
